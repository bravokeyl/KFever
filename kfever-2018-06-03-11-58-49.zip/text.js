const earlyText = "<p>I'm still evolving <break time='600ms'/>and my knowledge is limited <break time='600ms'/>so eventhough <break time='400ms'/>I may not be able to find everything you ask, I store your commands in my brain <break time='600ms'/>to help you serve better in the future.</p>";

const launchText = "Welcome to Korean Drama Fever.<break time='600ms'/><audio src='https://s3.amazonaws.com/ask-soundlibrary/impacts/amzn_sfx_fireworks_whistles_02.mp3'/> I can help you with Korean drama suggestions. For instance, you can ask me to recommend you a drama <break time='400ms'/>or to list recent dramas on DramaFever <break time='600ms'/>or on Netflix.<p>I can recommend really good, if I know your preferences,<break time='400ms'/> would you like to set your drama preferences now?</p>";
module.exports = {
  launchText
}
